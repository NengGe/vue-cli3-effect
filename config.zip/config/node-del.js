let fs = require('fs');
const path = require('path')

//获取从命令行传入的参数列表
// function getParamList(val, config) {
//   let valList = val.split('=');
//   if (valList[0] === config) {
//     return valList[1].split(',');
//   } else {
//     return [];
//   }
// }

// //获取从命令行传入的参数列表（去除默认传入的两个）
// let agrv = process.argv.slice(2);
// if (agrv.length > 0) {
//   agrv.forEach(function(val, index, array) {
//     let list = getParamList(val, '--targets');
//     console.log('list', list);
//     list.forEach(function(ele, ind) {
//       deleteTarget(ele || './dist');
//     })
//   });
// } else {
//   //如果从命令中没有传入参数，则直接默认删除顶级目录下的dist目录。
//   deleteTarget('./dist');
// }

// 删除目标文件夹或文件
function deleteTarget(fileUrl) {
  // 如果当前url不存在，则退出
  console.log(fileUrl)
  if (!fs.existsSync(fileUrl)) return;
  // 当前文件为文件夹时
  if (fs.statSync(fileUrl).isDirectory()) {
    let files = fs.readdirSync(fileUrl);
    let len = files.length,
      removeNumber = 0;
    if (len > 0) {
      files.forEach(function(file) {
        removeNumber++;
        let stats = fs.statSync(fileUrl + '/' + file);
        let url = fileUrl + '/' + file;
        if (fs.statSync(url).isDirectory()) {
          deleteTarget(url);
        } else {
          fs.unlinkSync(url);
        }

      });
      if (removeNumber === len) {
        // 删除当前文件夹下的所有文件后，删除当前空文件夹（注：所有的都采用同步删除）
        fs.rmdirSync(fileUrl);
        // console.log('删除文件夹' + fileUrl + '成功');
      }
    } else {
      fs.rmdirSync(fileUrl)
    }
  } else {
    // 当前文件为文件时
    fs.unlinkSync(fileUrl);
    // console.log('删除文件' + fileUrl + '成功');
  }
}
// deleteTarget(path.resolve(__dirname, '../build'))
module.exports = deleteTarget
